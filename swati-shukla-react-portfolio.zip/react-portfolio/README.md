# React Glassmorphism Portfolio

A modern responsive developer portfolio built with:

- React + Vite
- Tailwind CSS
- Lucide React icons
- Glassmorphism
- Scroll reveal animations
- Project category filters + carousel
- Skills proficiency bars
- Services bento grid
- Testimonial carousel
- Client-side contact-form validation
- Responsive mobile navigation

## Run locally

```bash
npm install
npm run dev
```

Then open the local URL shown by Vite.

## Production build

```bash
npm run build
npm run preview
```

## Customize

Edit `src/App.jsx`:

- Change name/title in `index.html` and the Hero/Footer.
- Replace email, GitHub, LinkedIn and Twitter URLs.
- Update `projects`, `skills`, and `testimonials`.
- Replace the emoji profile card with your own image.
- Connect `Contact` to Formspree, EmailJS, Resend, a serverless function, or your own API.

## Important

The contact form currently performs front-end validation only. It does not send email until you connect it to a backend/email provider.


## Personalized profile

This version is tailored to:
- AI Engineer / Data Science positioning
- Electrical Engineering background
- Executive PG Diploma in Data Science from IIIT Bangalore
- 1.5 years of teaching experience
- Python, SQL, Power BI, ML, Deep Learning, Generative AI, Prompt Engineering and RAG
- Loan Default Risk Analytics
- RSVP Movies global-audience analysis
- BoomBikes demand prediction
- Two power-systems research publications

Replace `your-email@example.com` and the social profile URLs in `src/App.jsx` with the actual contact details before publishing.
